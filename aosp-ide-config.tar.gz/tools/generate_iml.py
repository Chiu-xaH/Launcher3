#!/usr/bin/env python3
"""
AOSP Partial Checkout → Android Studio 跨文件跳转配置工具

自动扫描 AOSP 部分 checkout 中的所有 Java 源码目录，
生成 Android Studio .iml 配置文件，使 IDE 支持 Ctrl+Click 跨文件跳转。

适用场景：
  - 只有部分 AOSP 子目录（如 frameworks/base、packages/apps 等）
  - 没有完整 AOSP 源码树，无法使用 aidegen/idegen
  - 需要快速配置 Android Studio 使其支持代码导航

用法:
  python3 generate_iml.py [项目根目录]

  不传参数时，默认以当前脚本所在目录为项目根目录。
  项目根目录 = 包含 frameworks/、packages/、system/ 等子目录的顶层目录。

Windows 用法:
  python generate_iml.py D:\aosp-16

输出:
  在项目根目录下创建 .idea/ 目录，生成 aosp-xxxx.iml 配置文件。
"""

import os
import sys
from pathlib import Path


# ============================================================
# 配置区 —— 根据需要修改
# ============================================================

# 需要扫描源码的顶层目录（相对于项目根目录）
SEARCH_BASES = ["frameworks", "packages", "system"]

# 标识 Java 源码根目录的目录名
SOURCE_DIR_NAMES = {"java", "src"}

# 标记为测试目录的目录名（这些目录及其子目录不会被扫描）
TEST_ROOT_NAMES = {"tests", "apct-tests", "test", "androidTest", "testFixtures", "javatests"}

# 顶层噪音目录（完全排除，不索引）
TOP_EXCLUDE = {".git", ".idea", ".codeflicker", "out", "build", ".gradle"}

# packages/apps 下额外的 src 目录（手动补充，以防自动扫描遗漏）
EXTRA_APP_ROOTS = [
    "packages/apps/Launcher3/src",
    "packages/apps/Launcher3/quickstep/src",
    "packages/apps/Launcher3/shared/src",
    "packages/apps/Launcher3/dagger/src",
    "packages/apps/Launcher3/modules/concurrent/src",
    "packages/apps/Launcher3/modules/widgetpicker/src",
    "packages/apps/Launcher3/go/quickstep/src",
    "packages/apps/Launcher3/checks/src",
    "packages/apps/Settings/src",
]


# ============================================================
# 核心逻辑
# ============================================================

def find_project_root() -> Path:
    """自动推测项目根目录：脚本所在目录，或命令行参数指定的目录。"""
    if len(sys.argv) > 1:
        root = Path(sys.argv[1]).resolve()
    else:
        root = Path(os.path.dirname(os.path.abspath(__file__))).resolve()
    if not root.exists():
        print(f"❌ 目录不存在: {root}")
        sys.exit(1)
    return root


def is_test_dir(rel_path: str) -> bool:
    """判断路径中是否包含 test/tests 等测试根目录名。"""
    return any(p in TEST_ROOT_NAMES for p in Path(rel_path).parts)


def walk_pruned(root_path: Path, base: str):
    """遍历 base 目录，跳过隐藏目录和排除目录。"""
    base_path = root_path / base
    if not base_path.exists():
        return
    for dirpath, dirnames, _ in os.walk(base_path):
        dirnames[:] = [d for d in dirnames if d not in TOP_EXCLUDE and not d.startswith(".")]
        rel = os.path.relpath(dirpath, root_path)
        yield rel, dirnames, dirpath


def collect_java_source_roots(root_path: Path) -> list:
    """收集所有 */java 目录（排除测试目录下的）。"""
    roots = []
    for base in SEARCH_BASES:
        for rel, dirnames, dirpath in walk_pruned(root_path, base):
            if is_test_dir(rel):
                dirnames[:] = []  # 不再深入测试目录
                continue
            if os.path.basename(dirpath) == "java":
                roots.append(rel)
    # 添加额外应用入口
    for p in EXTRA_APP_ROOTS:
        if (root_path / p).exists():
            roots.append(p)
    return sorted(set(roots))


def collect_test_roots(root_path: Path) -> list:
    """收集所有测试根目录，用于 exclude。"""
    roots = []
    for base in SEARCH_BASES:
        for rel, dirnames, dirpath in walk_pruned(root_path, base):
            if is_test_dir(rel) or os.path.basename(dirpath) in TEST_ROOT_NAMES:
                roots.append(rel)
                dirnames[:] = []
    return sorted(set(roots))


def escape_xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def generate_iml(root_path: Path) -> None:
    """生成 .iml 文件。"""
    source_roots = collect_java_source_roots(root_path)
    test_roots = collect_test_roots(root_path)

    # 使用根目录名作为项目名
    project_name = root_path.name

    print(f"🔍 项目根目录: {root_path}")
    print(f"📂 源码根目录: {len(source_roots)} 个")
    print(f"🚫 排除测试目录: {len(test_roots)} 个")

    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<module type="JAVA_MODULE" version="4">',
        '  <component name="NewModuleRootManager" inherit-compiler-output="true">',
        '    <exclude-output />',
        '    <content url="file://$MODULE_DIR$">',
    ]

    for d in sorted(TOP_EXCLUDE):
        lines.append(f'      <excludeFolder url="file://$MODULE_DIR$/{escape_xml(d)}" />')

    for d in test_roots:
        lines.append(f'      <excludeFolder url="file://$MODULE_DIR$/{escape_xml(d)}" />')

    for d in source_roots:
        lines.append(f'      <sourceFolder url="file://$MODULE_DIR$/{escape_xml(d)}" isTestSource="false" />')

    lines += [
        '    </content>',
        '    <orderEntry type="inheritedJdk" />',
        '    <orderEntry type="sourceFolder" forTests="false" />',
        '  </component>',
        '</module>',
    ]

    idea_dir = root_path / ".idea"
    idea_dir.mkdir(parents=True, exist_ok=True)

    iml_path = idea_dir / f"{project_name}.iml"
    content = "\n".join(lines) + "\n"
    iml_path.write_text(content, encoding="utf-8")
    print(f"\n✅ 已生成: {iml_path}")
    print(f"   文件大小: {len(content):,} 字节")


def generate_modules_xml(root_path: Path) -> None:
    """生成 modules.xml。"""
    name = root_path.name
    xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<project version="4">
  <component name="ProjectModuleManager">
    <modules>
      <module fileurl="file://$PROJECT_DIR$/.idea/{name}.iml" filepath="$PROJECT_DIR$/.idea/{name}.iml" />
    </modules>
  </component>
</project>
'''
    (root_path / ".idea" / "modules.xml").write_text(xml, encoding="utf-8")
    print(f"✅ 已生成: .idea/modules.xml")


def generate_misc_xml(root_path: Path) -> None:
    """生成 misc.xml（SDK 配置模板，需要用户自行在 Android Studio 中确认 JDK）。"""
    xml = '''<?xml version="1.0" encoding="UTF-8"?>
<project version="4">
  <component name="ProjectRootManager" version="2" languageLevel="JDK_17" project-jdk-name="Android API 36.0 Platform" project-jdk-type="Android SDK">
    <output url="file://$PROJECT_DIR$/out" />
  </component>
</project>
'''
    path = root_path / ".idea" / "misc.xml"
    if not path.exists():
        path.write_text(xml, encoding="utf-8")
        print(f"✅ 已生成: .idea/misc.xml")
    else:
        print(f"⏭️  .idea/misc.xml 已存在，跳过")


def generate_gitignore(root_path: Path) -> None:
    """生成 .idea/.gitignore。"""
    path = root_path / ".idea" / ".gitignore"
    if not path.exists():
        path.write_text("# 默认忽略的文件\n/shelf/\n/workspace.xml\n", encoding="utf-8")
        print(f"✅ 已生成: .idea/.gitignore")


# ============================================================
# 主入口
# ============================================================

def main():
    root = find_project_root()

    print("=" * 55)
    print("  AOSP Android Studio IDE 配置生成器")
    print("=" * 55)

    generate_iml(root)
    generate_modules_xml(root)
    generate_misc_xml(root)
    generate_gitignore(root)

    print()
    print("=" * 55)
    print("  下一步:")
    print(f"  1. 在 Android Studio 中打开: {root}")
    print(f"  2. File → Project Structure → SDK 选择 Android API 36")
    print(f"  3. 等待右下角 Indexing 完成（首次约 5-15 分钟）")
    print(f"  4. Ctrl+Click / Cmd+Click 即可跨文件跳转")
    print("=" * 55)


if __name__ == "__main__":
    main()