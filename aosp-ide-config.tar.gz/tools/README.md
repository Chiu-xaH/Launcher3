# AOSP Partial Checkout → Android Studio 跨文件跳转配置

给只有部分 AOSP 源码（如 `frameworks/base`）的 Android Studio 项目配置完整的跨文件跳转（Ctrl+Click / Cmd+Click）。

## 适用场景

- 只有部分 AOSP 子目录，**没有**完整源码树
- 无法使用 `aidegen` / `idegen`（它们需要完整 AOSP + 编译产物）
- 需要在 Android Studio 中高效阅读和导航 AOSP 源码

## 文件说明

| 文件 | 用途 |
|------|------|
| `generate_iml.py` | **核心脚本** —— 自动扫描源码目录并生成 IDE 配置 |
| `setup-aosp-ide.sh` | macOS / Linux 一键运行 |
| `setup-aosp-ide.bat` | Windows 一键运行 |
| `README.md` | 本说明文档 |

## 前置条件

- **Python 3.6+**（macOS/Linux 自带；Windows 需安装）
- **Android Studio** 已安装并配置了 Android SDK（API 36 推荐）

## 快速开始

### macOS / Linux

```bash
# 1. 把 tools/ 目录放到你的 AOSP 部分 checkout 根目录下
#    结构应如下：
#    你的AOSP目录/
#    ├── frameworks/
#    │   ├── base/
#    │   └── native/
#    ├── packages/
#    ├── system/
#    └── tools/              ← 放这里
#        ├── generate_iml.py
#        └── README.md

# 2. 运行脚本
cd 你的AOSP目录
python3 tools/generate_iml.py

# 或者直接运行 shell 脚本
bash tools/setup-aosp-ide.sh
```

### Windows

```cmd
:: 1. 同样把 tools/ 目录放到 AOSP 根目录下
:: 2. 运行
cd D:\你的AOSP目录
python tools\generate_iml.py

:: 或者双击 setup-aosp-ide.bat
```

### 手动指定项目根目录

```bash
# 如果脚本不在项目根目录下，可以手动指定
python3 tools/generate_iml.py /path/to/your/aosp-root
```

## 脚本做了什么

1. **自动扫描** `frameworks/`、`packages/`、`system/` 下所有 `*/java` 和 `*/src` 目录
2. **自动排除** `tests/`、`apct-tests/`、`androidTest/` 等测试目录
3. **生成** `.idea/xxx.iml` —— 标记所有源码根目录
4. **生成** `.idea/modules.xml` —— 模块注册
5. **生成** `.idea/misc.xml` —— SDK 配置（如不存在）

## 在 Android Studio 中打开

1. 启动 Android Studio
2. **File → Open** → 选择你的 AOSP 根目录
3. 如果是首次打开：**File → Project Structure → SDK** 选择 `Android API 36.0 Platform`
4. 等待右下角 **Indexing** 进度条完成（首次约 5-15 分钟）
5. 打开任意 `.java` 文件，**Ctrl+Click** 方法名/类名，即可跳转到定义

## 目录结构要求

脚本假设你的项目根目录下有这些子目录之一：

```
项目根目录/
├── frameworks/          ← 必须至少有一个
│   ├── base/
│   │   ├── core/java/
│   │   ├── services/
│   │   └── ...
│   └── native/
├── packages/
│   └── apps/
│       ├── Launcher3/
│       └── Settings/
├── system/
│   └── core/
└── tools/               ← 本工具放这里
    ├── generate_iml.py
    └── README.md
```

如果没有以上结构，可以修改 `generate_iml.py` 顶部的 `SEARCH_BASES` 配置。

## 常见问题

### Q: 跳转时提示 "Cannot find declaration to go to"？

- 确认索引已完成（右下角无进度条）
- 确保依赖的模块也在你的 checkout 范围内（跨 checkout 范围的引用无法跳转是正常的）

### Q: 配置后需要重启 Android Studio 吗？

- 通常不需要，IDE 会自动检测 `.iml` 变化并重新索引
- 如果没有自动生效，手动 **File → Invalidate Caches → Invalidate and Restart**

### Q: 如何在 Windows 和 Mac 之间共享这套配置？

- 直接把整个项目目录拷贝到另一台机器
- 重新运行 `generate_iml.py` 即可（路径使用 `$MODULE_DIR$` 变量，跨平台兼容）

### Q: 想要添加额外的源码目录？

- 编辑 `generate_iml.py` 顶部的 `EXTRA_APP_ROOTS` 列表，添加路径后重新运行

## 恢复备份

如果不满意生成结果，删除以下文件即可恢复：

```bash
rm .idea/*.iml
```

然后用 `File → Open` 重新打开项目，Android Studio 会重建默认配置。