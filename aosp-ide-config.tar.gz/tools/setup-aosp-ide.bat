@echo off
REM AOSP Android Studio IDE 配置 —— Windows 一键运行
REM 用法: tools\setup-aosp-ide.bat
set SCRIPT_DIR=%~dp0
pushd "%SCRIPT_DIR%.."
set PROJECT_ROOT=%CD%
popd
echo AOSP 项目根目录: %PROJECT_ROOT%
python "%SCRIPT_DIR%generate_iml.py" "%PROJECT_ROOT%"
pause