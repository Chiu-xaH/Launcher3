#!/bin/bash
# AOSP Android Studio IDE 配置 —— macOS / Linux 一键运行
# 用法: bash tools/setup-aosp-ide.sh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
echo "AOSP 项目根目录: $PROJECT_ROOT"
python3 "$SCRIPT_DIR/generate_iml.py" "$PROJECT_ROOT"